package com.example.randy

import android.os.Bundle
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_random.*
import kotlin.random.Random

fun rand(start: Int, end: Int): Int {
    require(!(start > end || end - start + 1 > Int.MAX_VALUE)) { "Illegal Argument" }
    return Random(System.nanoTime()).nextInt(end - start + 1) + start
}

class RandomActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_random)

        //val min = Integer.parseInt(intent.getStringExtra("min"))
        //val max = Integer.parseInt(intent.getStringArrayExtra("settings"))
        //val players = Integer.parseInt(intent.getStringExtra("players"))



        btnRandomize.setOnClickListener {
            val n = rand(0, 100)
            if(n == 0){
                number.text = "Du må suge Sander Berg, eller så blir det 0"
            }
            else {
                number.text = n.toString()
            }

        }
    }
}