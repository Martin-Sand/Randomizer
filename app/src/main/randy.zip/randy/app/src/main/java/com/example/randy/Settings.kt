package com.example.randy

import java.io.Serializable

data class Settings (
    val high: Int,
    val low: Int,
    var players: Int) : Serializable