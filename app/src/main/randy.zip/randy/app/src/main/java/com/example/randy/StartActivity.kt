package com.example.randy

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_start.*


class StartActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start)

        supportActionBar?.hide()

        Start.setOnClickListener {
            val b = Bundle()
            val players = Integer.parseInt(nPlayers.text.toString())
            val min = Integer.parseInt(low.text.toString())
            val max = Integer.parseInt(high.text.toString())
            val key = "settings"

            val intent = Intent(this@StartActivity, RandomActivity::class.java)
            startActivity(intent)
        }
    }
}